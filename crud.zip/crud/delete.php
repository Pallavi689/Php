<?php include  "header.php" ; ?>
<html>
    <head>
    <link rel="stylesheet" href="style.css"> 
  
        <style>
            <style>
        form{
            background-color: #f2f2f2;
        }
        .box {
   
       margin: auto;
       width: 50%;
       border-radius: 5px;
       background-color: #f2f2f2;
   
   /* padding: 10px; */

   /* height: 200px;  */
 }
 .h1{
  margin-top: 140px;
  text-align: center;
 }
 .but{
  background-color: #e1ecf4;
  border-radius: 3px;
  border: 1px solid #7aa7c7;
  box-shadow: rgba(255, 255, 255, .7) 0 1px 0 0 inset;
  box-sizing: border-box;
  color: #39739d;
  cursor: pointer;
  display: inline-block;
  font-family: -apple-system,system-ui,"Segoe UI","Liberation Sans",sans-serif;
  font-size: 13px;
  font-weight: 400;
  line-height: 1.15385;
  margin: 0;
  outline: none;
  padding: 8px .8em;
  position: relative;
  text-align: center;
  text-decoration: none;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  vertical-align: baseline;
  white-space: nowrap;
}


        </style>
    </head>
    <body>
    <?php
    if(isset($_POST['show'])){
        $data = mysqli_connect("localhost","root","","crud") or die("not connect");
    $url_s_id = $_POST['sid'] ;
   
    $sql = "DELETE FROM student WHERE s_id = '{$url_s_id}'";
    $result=mysqli_query($data,$sql) or die("query not set");
    header("Location: http://localhost/crud/show_table.php");
    mysqli_close($data);
    }?>
    <h1 class = "h1">UPDATE RECORD</h1>
    <div class = "box">

       <form action ="<?php echo $_SERVER['PHP_SELF'];?>" method = "POST">
       <label for="">ID</label>
        <input type="text" name = "sid"><br><br>
        
        <input type = "submit" name = "show" class = "but">
        

        </form>

</div>

       

    </body>
</html>