<?php include  "header.php" ; ?>
<html>
  
  <head> <meta name="viewport" content=
        "width=device-width, initial-scale=1" />
    <script src=
"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js">
    </script> 
    
    
   
   
  
  </head>
<body >
    <style>
      .box {
   
   margin: auto;
   width: 50%;
   border-radius: 5px;
   background-color: #f2f2f2;
   
   /* padding: 10px; */

   height: 200px; 
 }
        table, tr, td {
          border: 1px solid black;
  border-collapse: collapse;
  
       }
       table{
        width: 100%;
       }
       td {
  height: 50px;
  text-align: center;
}
   
 .h1{
  margin-top: 140px;
  text-align: center;
 }
 button{
  background-color: #e1ecf4;
  border-radius: 3px;
  border: 1px solid #7aa7c7;
  box-shadow: rgba(255, 255, 255, .7) 0 1px 0 0 inset;
  box-sizing: border-box;
  color: #39739d;
  cursor: pointer;
  display: inline-block;
  font-family: -apple-system,system-ui,"Segoe UI","Liberation Sans",sans-serif;
  font-size: 13px;
  font-weight: 400;
  line-height: 1.15385;
  margin: 0;
  outline: none;
  padding: 8px .8em;
  position: relative;
  text-align: center;
  text-decoration: none;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  vertical-align: baseline;
  white-space: nowrap;
}





 .but{
  margin: auto;
 }

    </style>
<?php
$data = mysqli_connect("localhost","root","","crud") or die("not connect");
$sql = "SELECT * FROM student ";
$result=mysqli_query($data,$sql) or die("query not set");
if(mysqli_num_rows($result) > 0){
?>
 <h1 class = "h1">Read</h1>
<div >

<table class = "box">
  <tr>
    <td>id</td>
    <td>name</td>
    <td>roll no.</td>
    <td>address</td>
    <td>phone no.</td>
    <td>course </td>
    <td> update </td>
    <!-- <td>class </td> -->
  </tr>
  <?php
  while($row = mysqli_fetch_assoc($result)){
  ?>
  
  <tr>
    <td><?php echo $row['s_id'];?></td>
    <td><?php echo $row['s_name'];?></td>
    <td><?php echo $row['ro_no'];?></td>
    <td><?php echo $row['s_address'];?></td>
    <td><?php echo $row['phone'];?></td>
    <td><?php echo $row['course'];?></td>
    
    <!-- update.php?id= this line is used to pass id(in a url) for update the info of the student by giving student id -->
   <td ><a href="create_data.php"><button> add </button></a>
      <a href="update.php?id=<?php echo $row['s_id'];?>"><button> edit </button></a> 
    <a href="delete.php?id=<?php echo $row['s_id'];?>"> <button > delete </button></a></td>
  </tr>
  <?php } ?>
</table>
  </div>
<?php }else{
    echo "no record";
} ?>


</body>
</html>