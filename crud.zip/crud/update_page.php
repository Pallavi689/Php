<?php include  "header.php" ; ?>
<html>
    <head>
    <link rel="stylesheet" href="style.css"> 
    <style>
        form{
            background-color: #f2f2f2;
        }
        .box {
   
       margin: auto;
       width: 50%;
       border-radius: 5px;
       background-color: #f2f2f2;
   
   /* padding: 10px; */

   /* height: 200px;  */
 }
 .h1{
  margin-top: 140px;
  text-align: center;
 }
 .but{
  background-color: #e1ecf4;
  border-radius: 3px;
  border: 1px solid #7aa7c7;
  box-shadow: rgba(255, 255, 255, .7) 0 1px 0 0 inset;
  box-sizing: border-box;
  color: #39739d;
  cursor: pointer;
  display: inline-block;
  font-family: -apple-system,system-ui,"Segoe UI","Liberation Sans",sans-serif;
  font-size: 13px;
  font-weight: 400;
  line-height: 1.15385;
  margin: 0;
  outline: none;
  padding: 8px .8em;
  position: relative;
  text-align: center;
  text-decoration: none;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  vertical-align: baseline;
  white-space: nowrap;
}



    </style>
    </head>
    <body>
    <h1 class = "h1">UPDATE RECORD</h1>
   <?php $data = mysqli_connect("localhost","root","","crud") or die("not connect");?>
   <div class = "box">
    <form method ="post" action ="<?php echo $_SERVER['PHP_SELF'];?>">
            <!-- show the value by using id  in a (value block)-->
        <label>ID</label> 
        <input type="text" name = "sid1"><br><br>
        <input type = "submit" name = "show" class = "but">

        </form>
</div>
        <?php
        if( isset($_POST["show"])){
        $url_s_id = $_POST['sid1'];
       
        // $url_s_id is a variable which is take the value of user id because id pass in a url (show_table.php edit button) id is a primary key of our database get is a method
        //$url_s_id = $_GET['id'] ;
        $sql = "SELECT * FROM student where s_id = {$url_s_id} ";
        $result=mysqli_query($data,$sql) or die("enter a valid id");
        if(mysqli_num_rows($result) > 0){
        while($row=mysqli_fetch_assoc($result)){
    ?>
    <br><br>
    <div class = "box">
        <form method ="post" action ="sqlupdate.php" >
        <label >name:</label>
        <input type="hidden" name = "sid" value = "<?php echo $url_s_id;?>">
        <input type="text" name = "name" value ="<?php echo $row['s_name'];?>"><br><br>
        roll number : <input type="text" name = "ro_no" value ="<?php echo $row['ro_no'];?>"><br><br>
        address : <input type = "text" name="address"  value ="<?php echo $row['s_address'];?>"><br><br>
        
        phone : <input type="text" name= "phone" value ="<?php echo $row['phone'];?>"><br><br>
        <label >course :</label>
        
        <select name="course" >
        
        <option name="op" value ="<?php echo $row['course'];?>">select class</option>
        <?php
       
       $sql1 = "SELECT DISTINCT course FROM student";
       $result1=mysqli_query($data,$sql1) or die("query not set");
       while ($row1 = mysqli_fetch_assoc($result1)){
           
       ?>
        
        <option ><?php echo $row1["course"];?></option>
        <?php } ?>
        </select><br><br>
        
        <button class = "but">update</button>
</form>
       </div>
<?php }}}?>
    </body>
</html>