<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="style.css" />
    <title>Fantacy Design | Sticky Navigation</title>
    <style>
@import url('https://fonts.googleapis.com/css?family=Open+Sans');
 
* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}
 
body {
  font-family: 'Open Sans', sans-serif;
  color: #222;
  padding-bottom: 50px;
}
span{
  color: #1DBF73;
  font-size: 50px;
}
span:hover{
  color: #fff;
  transition: 0.5s;
}
.container {
  max-width: 1200px;
  margin: 0 auto;
}
.logo{
font-size: 46px;
color: #fff'
}
.nav {
  position: fixed;
  background-color: #222;
  top: 0;
  left: 0;
  right: 0;
  height: 100px;
  transition: all 0.3s ease-in-out;
}
 
.nav .container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px 0;
  transition: all 0.3s ease-in-out;
}
 
.nav ul {
  display: flex;
  list-style-type: none;
  align-items: center;
  justify-content: center;
}
 
.nav a {
  color: #fff;
  text-decoration: none;
  padding: 7px 15px;
  transition: all 0.3s ease-in-out;
}
 
.nav.active {
  background-color: #fff;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
}
 
.nav.active a {
  color: #000;
}
 
.nav.active .container {
  padding: 10px 0;
}
 
.nav a.current,
.nav a:hover {
  color: #1DBF73;
  font-weight: bold;
}
  </style>
  </head>
  <body>
    <nav class="nav">
      <div class="container">
        <h1 class="logo"><a href="/index.html">C<span>URD</span</a></h1>
        <ul>
          <li><a href="show_table.php" class="current">Home</a></li>
          <li><a href="create_data.php">Create</a></li>
          <li><a href="show_table.php">Read</a></li>
          <li><a href="update_page.php">Update</a></li>
          
          <li><a href="delete.php">dalete</a></li>
        </ul>
      </div>
    </nav>
 
    
    
    <script src="script.js"></script>
  </body>
</html>