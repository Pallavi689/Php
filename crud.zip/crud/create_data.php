<?php include  "header.php" ; ?>
<html>

    
        <head>
        <meta name="viewport" content=
        "width=device-width, initial-scale=1" />
    <script src=
"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js">
    </script>

     <!-- css link -->
   <link rel="stylesheet" href="style.css"> 
  
        </head>
<body>
    <div class = "top"><h1 class = "h">CREATE </h1></div><br>
    <div class = "box">
    <form method ="post" action ="save.php">
       <label for=""> name :</label>
         <input type="text" name = "name"><br><br>
        <label for="">roll number :</label> <input type="text" name = "ro_no"><br><br>
        <label for="">address :</label> <input name="address" type = "text"><br><br>
        
        <label for="">phone :</label> <input type="text" name= "phone"><br><br>
        
        <label for="">course :</label><select name="course">
        
        <option name="op">select class</option>
        <?php
        $data = mysqli_connect("localhost","root","","crud") or die("not connect");
        $sql = "SELECT DISTINCT course FROM student";
        $result=mysqli_query($data,$sql) or die("query not set");
        while ($row = mysqli_fetch_assoc($result)){
        ?>
        <option ><?php echo $row["course"];?></option>
        <?php } ?>
        </select><br><br>
        
       <button class = "but">submit</button>
</form>
        </div>
</body>
    </html>